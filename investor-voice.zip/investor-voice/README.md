# Investor Voice

Rewrite your investor letter in the voice of the people who wrote the best ones.

I'm not a coder. I grew up running a company from age 17 and never properly learned how to communicate with investors. So I read the people who did it best — **Mark Leonard** of Constellation Software, **Marc Andreessen**, and **Jeff Bezos** — pulled apart their voices, and built a tool that rewrites your draft in theirs.

Paste a draft or bullet points, pick a voice, get a letter that sounds like one of them wrote it.

It's free. The code's here. Fork it, swap the authors, make your own version.

## Try it

→ Live app: [LINK_TO_LOVABLE_APP]

## How it works

There's no model training, no fine-tuning, no vector database. The trick is in the author packs.

Each author pack (`/authors/leonard.md`, `/andreessen.md`, `/bezos.md`) is a compressed style fingerprint extracted from that person's published writing — sentence rhythm, vocabulary, signature rhetorical moves, anti-patterns, and a few short exemplar quotes for calibration. The system prompt (`/prompts/system.md`) tells Claude how to use the pack to rewrite an arbitrary input.

That's it. The whole thing is one API call to the Claude API.

The reason it works better than just asking ChatGPT to "write like Bezos" is that the author packs encode the *specific* things each writer does and doesn't do — Leonard's preference for parenthetical qualifiers over adjectives, Andreessen's em-dash habit and enumerated-list arguments, Bezos's principle-naming and the ritual reprint of the 1997 letter. Models don't know these by default. The pack tells them.

## Why these three

- **Mark Leonard** — for the founder who needs to sound serious. Dry, metric-driven, no hype.
- **Marc Andreessen** — for the founder making a thesis-driven, contrarian argument. Punchy, structured, high information density. (The pack uses his 2007–2009 pmarca voice, not the recent manifesto voice — see `/authors/andreessen.md` for why.)
- **Jeff Bezos** — for the founder building long-term, who needs to communicate strategic patience. Plain language, principle-anchored, customer-obsessed.

Want a different author? It's about a day's work. See "Forking" below.

## Repo structure

```
investor-voice/
├── README.md               this file
├── LICENSE                 MIT
├── authors/
│   ├── leonard.md          Mark Leonard style pack
│   ├── andreessen.md       Marc Andreessen style pack
│   └── bezos.md            Jeff Bezos style pack
├── prompts/
│   ├── system.md           the system prompt for the API call
│   └── transform.md        the user-message template
├── corpus/
│   └── sources.md          links to the public source material
└── app/
    └── README.md           pointers to the Lovable app
```

## Forking — add your own author

1. Pick a writer with a substantial corpus of investor-facing writing that's actually written by them (not interviews or transcripts).
2. Read their letters carefully — at least 8–10 of them.
3. Copy `authors/leonard.md` as a template and fill in:
   - Voice fingerprint (tone, sentences, vocabulary)
   - Signature rhetorical moves
   - Structural patterns
   - Anti-patterns
   - 3–5 short exemplar quotes (keep each under 15 words, attribute properly)
4. Add the new author to the picker in the Lovable app.

The hardest part is being honest about what the writer actually does, vs what you wish they did.

## Credits

Inspired by Saagar's *one letter a day* practice — which is the reason I started reading these in the first place.

Voice-pack methodology inspired by the technique the *Strawberry* founder used to scrape and analyze the *Lovable* founder's posts.

## License

MIT for the code and the author packs.
Source letters belong to their respective authors and publishers — we don't redistribute them.

## Built with

- [Claude API](https://www.anthropic.com/api) for the rewrite
- [Lovable](https://lovable.dev/) for the frontend
- A weekend
