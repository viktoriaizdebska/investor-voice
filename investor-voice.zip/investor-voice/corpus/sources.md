# Corpus Sources

This repo does not redistribute the source letters in full, out of respect for the authors and their publishers. We link to the canonical public locations and use only short, attributed exemplar quotes (under 15 words each) in the author packs.

If you want to fork and extend this project, here's where to read the source material.

## Mark Leonard — Constellation Software President's Letters

- Official archive: https://www.csisoftware.com/category/pres-letters
- Consolidated PDF (third-party, useful for reading sequentially): https://quartr.com/insights/business-philosophy/collection-mark-leonards-shareholder-letters
- Coverage: Quarterly 2007–2010, annual 2010–present.

The annual letters from 2010 onward are the most useful for voice calibration. The early quarterly letters are short and operational; the annual letters are where Leonard's full voice develops.

## Marc Andreessen — pmarca essays

- Curated archive (recommended starting point): https://pmarchive.com/
- Official a16z PDF of the blog archives: https://a16z.com/the-pmarca-blog-archive-is-back-as-an-ebook/
- Current Substack: https://pmarca.substack.com/
- "Why Software Is Eating the World" (WSJ, 2011): widely available
- "The Techno-Optimist Manifesto" (a16z, 2023): https://a16z.com/the-techno-optimist-manifesto/

Note: the 2007–2009 pmarca voice (tactical, operator-philosopher) is different from the 2020s manifesto voice. For founder→investor communications, the early voice is almost always the better target. The Substack and Manifesto materials are useful only for vision-statement-style writing.

## Jeff Bezos — Amazon shareholder letters

- All annual letters 1997–2020 are filed publicly with the SEC each year as exhibits to Amazon's 10-K.
- Amazon's investor relations site: https://ir.aboutamazon.com/annual-reports-proxies-and-shareholder-letters/default.aspx
- Many curated collections exist online; the SEC versions are canonical.

The 1997 letter is reprinted every year — it's worth reading once carefully, then skimming each subsequent year for what's added.

## A note on rights

The author packs in `/authors` are original analysis — voice fingerprints, rhetorical patterns, structural observations. That's our work and is MIT-licensed.

The short exemplar quotes (each under 15 words, attributed by source and date) are used under fair-use principles for the purpose of stylistic commentary and education.

We do not redistribute the full text of any letter in this repo. If you want to read the source material, please follow the links above.
