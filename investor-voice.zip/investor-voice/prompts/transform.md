# User Message Template

This is the template that wraps each user request before sending to the API. The Lovable frontend should fill in the four sections and send the result as the user message, with the system prompt (system.md) as the system message.

---

<author_pack>
{{INSERT FULL CONTENTS OF authors/leonard.md OR andreessen.md OR bezos.md HERE}}
</author_pack>

<user_input_type>
{{ONE OF: "draft_to_rewrite" OR "bullet_points_to_compose"}}
</user_input_type>

<user_input>
{{THE USER'S PASTED TEXT}}
</user_input>

<optional_context>
{{ANY CONTEXT THE USER PROVIDED — company stage, audience, occasion. Omit this tag entirely if blank.}}
</optional_context>

Rewrite the user_input in the voice described in the author_pack, following all rules in your system instructions.
